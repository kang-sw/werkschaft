import type {
  SessionCompactResult,
  SessionCompactTrigger,
  SessionContextUsage,
  SessionUsage,
} from 'claude-code'

import type { OwnPrompt, OwnSubmitResult } from './captions'
import {
  checkLeverCall,
  deliveryLine,
  deliveryText,
  leverResult,
  levelAt,
  observe,
  percentOf,
  resolveAdvisory,
  resumeLine,
  resumeText,
  thresholdsFor,
  vetoedResumeLine,
  vetoedResumeText,
  DEFAULT_ADVISORY,
  type AdvisorySpec,
  type Level,
  type Thresholds,
} from './timing'

/**
 * Lead compaction timing, the compaction feature of the Claude mod: an
 * advisory and two milestone wake turns before native auto compaction, and
 * a lever tool the lead calls at a boundary of its own choosing. The engine
 * still writes the summary, and its auto compaction stays the hard point: the
 * feature never vetoes or preempts a compaction.
 *
 * The resume prompt is opt-in: a lever call without its `continue` flag
 * (work does not need to resume by itself) submits nothing after the step
 * and opens no window, and a veto is told to the person through a transcript
 * notice only.
 *
 * With the flag, the fixed resume prompt after the lever's own compaction
 * (landed or vetoed) is held for CONTINUATION_WINDOW_MS rather than submitted
 * at once, and any main-thread turn starting within the window cancels it: a
 * prompt the person typed during the compaction, or a background agent's
 * notification, already started the first turn after it, which resumes the
 * work there, so the resume would arrive only as a stale prompt after that
 * turn. The window's end submits it only when no turn started.
 *
 * The advisory point is the configured one, read once per session start
 * (readAdvisory) and not awaited: until the read settles, and whenever it
 * fails or its value does not parse, the default applies. A read that settles
 * after the thresholds were cached drops the cache, so the configured point
 * applies from the next usage observation of that session.
 *
 * A threshold message reports usage as of its delivery, not of the
 * observation that crossed: session.measure also fires mid-turn (a rate-limit
 * window moving a point, a subagent's requests among them), and the rest of
 * that turn grows the context before a submitted prompt reaches the model. So
 * a crossing observed while a main-thread turn runs is only recorded, and is
 * delivered at whichever comes first of an observation while no main-thread
 * turn runs and a main-thread turn end not aborted; delivery reads the usage
 * afresh and figures the level and the figures from that read.
 *
 * Main session only: thresholds read the main thread's usage, the lever
 * refuses a subagent, and a subagent's or fork's own compaction is ignored.
 * The engine calls arrive as edges bound in register.ts, so the state machine
 * here is driven and tested without an engine.
 */

/** How long the lever's resume prompt waits for another prompt to start the first turn after its compaction. */
export const CONTINUATION_WINDOW_MS = 1500

/**
 * How long after a main-thread turn end the compact step waits before it
 * checks for a running turn: a prompt already queued in the engine starts its
 * turn first, so the check sees it rather than queueing `/compact` behind it.
 */
export const SETTLE_MS = 1000

/** The skip reason of a lever compaction whose command ran with no landing or veto observed. */
export const UNOBSERVED_REASON = 'no compaction was observed'

export type CompactionEdges = {
  /**
   * Queue a prompt that starts its own turn once the session is idle: its
   * text, and the one-liner the person sees while captions are on. With
   * captions on it may submit nothing: `busy` when a main-thread turn started
   * first, `stale` when `live` read false after the wait (see submitOwn).
   */
  submit: (prompt: OwnPrompt, live: () => boolean) => Promise<OwnSubmitResult>
  /**
   * Run the `/compact` slash command; resolves once it ran, and rejects when
   * the engine refuses it (an unknown name, inside a hook the turn waits on,
   * past a Stop or a host's limit). Its outcome is not in the answer: the
   * compaction passes the mod's own session.compact hook, which reports it
   * through `compacted` while the call is awaited.
   */
  compact: () => Promise<unknown>
  /** Run `fn` once, after the calling hook has returned. */
  after: (fn: () => void) => void
  /** Run `fn` once, `ms` from now. */
  delay: (ms: number, fn: () => void) => void
  log: (text: string, to: 'transcript' | 'debug') => void
  /** The engine-reported plugin name: the prompts' label and the log lines' prefix spell it. */
  plugin: string
  /** Whether a main-thread turn runs, from its turn.start to its turn.complete. */
  turnRunning: () => boolean
  /** Read the live usage afresh, without a breakdown; a threshold message's figures come from it. */
  readUsage: () => Promise<SessionContextUsage>
  /**
   * Read the configured advisory point's stored value, called once per
   * session start; absent, a rejection, or a value that does not parse leaves
   * the default.
   */
  readAdvisory?: () => Promise<unknown>
}

/** The lever tool's answer: a refusal or its result text. */
export type LeverAnswer = { deny: string } | { result: string }

export type Compaction = {
  /** session.start: bind the edges and start the conversation's state over. */
  start: (edges: CompactionEdges) => void
  /** session.end: start the conversation's state over; any end reason. */
  end: (reason: string) => void
  /** A lever tool call. */
  lever: (agentId: string | undefined, flag: unknown) => LeverAnswer
  /**
   * A session.measure: compare usage with the thresholds and record a
   * crossing; while no main-thread turn runs, deliver it at once (at most one
   * threshold message).
   */
  measure: (context: SessionContextUsage, readBreakdown: () => Promise<SessionUsage>) => Promise<void>
  /** A turn.start: a main-thread one cancels a held resume prompt. */
  turnStarted: (agentId: string | undefined) => void
  /**
   * A turn.complete: schedule a recorded crossing's delivery, and a pending
   * request's compact step, or submit its resume prompt.
   */
  turnComplete: (agentId: string | undefined, reason: string) => void
  /** A session.compact as it settled beneath the feature's hook. */
  compacted: (trigger: SessionCompactTrigger, agentId: string | undefined, res: SessionCompactResult) => void
  /**
   * Resolves once no resume prompt is pending: none is owed by the lever's
   * awaited compaction, none is held for its window, and every one submitted
   * has settled (its submit resolves as its turn starts, or it was not
   * submitted). At once when none is. The mailbox push waits on it at a
   * compaction end, so held dashboard messages follow the continuation.
   */
  continuation: () => Promise<void>
  /**
   * Whether the main-thread turn ending with `reason` carried a lever call
   * whose compact step is still owed: read at that turn end before
   * turnComplete hears of it, so the mailbox push holds queued dashboard
   * messages for the compaction. False once that turn end passed (it arms
   * once per lever call), for an aborted turn (the request is parked, and
   * no step is scheduled), and once a compaction landed first.
   */
  leverPending: (reason: string) => boolean
}

/** A lever call waiting for its turn to end. */
type Request = {
  /** Whether the latest call set the `continue` flag; unset leaves nothing to submit. */
  resume: boolean
  /** False once a compaction landed elsewhere first: the resume prompt (if any) is still owed, the compact step is not. */
  compact: boolean
  /**
   * The token of its queued compact step, from the turn end that queued it
   * until that step starts; undefined while none is queued.
   */
  scheduled: number | undefined
  /** Set at the first main-thread turn end after the latest lever call; see Compaction.leverPending. */
  ended: boolean
}

/** The breakdown's figures, keyed by the model window they were read under. */
type Cached = { window: number; thresholds: Thresholds | undefined }

function describeAdvisory(spec: AdvisorySpec): string {
  const terms = [spec.percent !== undefined ? `${spec.percent}%` : undefined, spec.tokens !== undefined ? `${spec.tokens} tokens` : undefined]
  return terms.filter((t) => t !== undefined).join(' or ')
}

function describeWindow(t: Thresholds | undefined): string {
  if (!t) return 'thresholds off (auto compaction off, or its point not above the advisory point)'
  const p = (tokens: number) => `${percentOf(tokens, t.raw)}%`
  return `window ${t.raw} tokens: advisory ${p(t.advisory)}, milestones ${p(t.m1)} and ${p(t.m2)}, auto compaction ${p(t.hard)}`
}

export function createCompaction(): Compaction {
  let edges: CompactionEdges | undefined
  let cached: Cached | undefined
  /** The level last delivered; undefined until the first usage observed since a session start or end. */
  let latch: Level | undefined
  /**
   * A crossing above the latch not delivered yet, with the usage of the
   * observation that first recorded it (for the delivery's debug line).
   */
  let crossing: { tokens: number } | undefined
  /** True while a delivery awaits its usage read: a second one waits for the next delivery point. */
  let delivering = false
  let request: Request | undefined
  /** The lever's resume prompt held for its window; see CONTINUATION_WINDOW_MS. */
  let held: { prompt: OwnPrompt } | undefined
  /** Resume prompts submitted whose submit has not settled yet. */
  let resuming = 0
  /** continuation()'s waiters, resolved by settle() once no resume prompt is pending. */
  let waiters: (() => void)[] = []
  /**
   * True while the lever's awaited `/compact` command is pending. A
   * main-conversation compaction the feature's hook sees meanwhile is the
   * lever's own (it lands with a `manual` trigger, like a typed `/compact`,
   * so the trigger cannot tell them apart): its result is kept in
   * leverOutcome for runLever, and it does not drop the request as another's
   * landing would.
   */
  let leverCompacting = false
  /** The lever's own compaction as the hook saw it settle; undefined until one is seen. */
  let leverOutcome: SessionCompactResult | undefined
  /** The advisory point the thresholds use; the default until a session start's read settles. */
  let advisory: AdvisorySpec = DEFAULT_ADVISORY
  /** Bumped at every session start: a read from an earlier start is dropped. */
  let reads = 0
  /** The last compact-step token handed out; see Request.scheduled. */
  let dispatches = 0
  /**
   * Bumped at every session start or end and every landed main-conversation
   * compaction: an observation that awaited the breakdown across one of them
   * holds usage from before it and is dropped.
   */
  let generation = 0

  const plugin = () => edges?.plugin ?? 'plugin'
  const debug = (text: string) => edges?.log(`${plugin()} compaction: ${text}`, 'debug')
  const notice = (text: string) => edges?.log(`${plugin()} compaction: ${text}`, 'transcript')

  /** Whether a resume prompt is pending; see Compaction.continuation. */
  const continuing = () => (leverCompacting && request?.resume === true) || held !== undefined || resuming > 0

  /** Resolve continuation()'s waiters once no resume prompt is pending; called after every change continuing() reads. */
  const settle = () => {
    if (waiters.length === 0 || continuing()) return
    const ready = waiters
    waiters = []
    for (const resolve of ready) resolve()
  }

  const reset = () => {
    generation += 1
    cached = undefined
    latch = undefined
    crossing = undefined
    request = undefined
    held = undefined
    settle()
  }

  /**
   * Queue `prompt`; not awaited, since a submit resolves only as its turn
   * starts. A lost `record`ed prompt (a resume) is written to the
   * transcript, so the person sees the work was meant to resume. One a
   * session start, end or landed compaction made stale before it went out is
   * dropped; `busy` (a main-thread turn started first) is the caller's.
   */
  const submit = (prompt: OwnPrompt, record: boolean, busy: () => void) => {
    if (!edges) return
    const gen = generation
    const failed = (why: string) =>
      record ? notice(`a prompt was not submitted (${why}):\n${prompt.text}`) : debug(`a prompt was not submitted (${why})`)
    // A recorded prompt is a resume: pending for continuation() until its submit settles.
    if (record) resuming += 1
    const settled = () => {
      if (!record) return
      resuming -= 1
      settle()
    }
    edges.submit(prompt, () => gen === generation)
      .then(
        (res) => {
          if (res.stale) debug('the conversation moved on before a prompt went out; it is not submitted')
          else if (res.busy) busy()
          else if (res.drop !== undefined) failed(`dropped: ${res.drop}`)
        },
        (err) => failed(String(err)),
      )
      .finally(settled)
  }

  /** A resume prompt that found a main-thread turn started first: that turn carries the work on, as within the window. */
  const resumeBusy = () => debug('a main-thread turn started before the resume prompt went out; it is not submitted')

  /** A landed main-conversation compaction: the latch and the breakdown start over. */
  const landed = () => {
    generation += 1
    cached = undefined
    latch = 0
    crossing = undefined
  }

  /**
   * Deliver the recorded crossing with a fresh usage read: its level and its
   * figures are that read's, so a crossing that grew past the next milestone
   * meanwhile delivers the higher one. No threshold message while a lever
   * request is pending (its turn could start first and hold the compact step,
   * or land beside the resume prompt with stale figures), nor while its
   * resume prompt is held (a threshold turn would start first and cancel it),
   * nor once a main-thread turn started during the read: the crossing then
   * stays recorded for a later delivery point.
   */
  const deliver = async () => {
    const c0 = cached
    const t = c0?.thresholds
    if (!edges || !crossing || delivering || !t || request !== undefined || held !== undefined) return
    const gen = generation
    let fresh: SessionContextUsage
    delivering = true
    try {
      fresh = await edges.readUsage()
    } catch (err) {
      debug(`usage not read for delivery (${String(err)}); the crossing stays recorded`)
      return
    } finally {
      delivering = false
    }
    const crossed = crossing
    if (gen !== generation || cached !== c0 || !crossed || request !== undefined || held !== undefined || edges.turnRunning()) return
    // Thresholds figured under another model window are stale; the next observation reads the breakdown again.
    if (fresh.window !== c0.window) return
    const tokens = fresh.tokens ?? crossed.tokens
    const before = latch
    const step = observe(latch, levelAt(t, tokens), true)
    latch = step.latch
    crossing = undefined
    if (!step.deliver) return
    debug(
      `${step.deliver.kind === 'advisory' ? 'advisory' : `milestone ${step.deliver.which}`} delivered: ` +
        `crossing measured at ${crossed.tokens} tokens (${percentOf(crossed.tokens, t.raw)}%), ` +
        `fresh read ${fresh.tokens === undefined ? 'without tokens, so the crossing\'s figure is shown' : `${fresh.tokens} tokens (${percentOf(fresh.tokens, t.raw)}%)`}, ` +
        `compaction window ${t.raw} tokens, model window ${fresh.window} tokens`,
    )
    const delivered = step.latch
    // A turn that started first takes the crossing back: delivered at its end with fresh figures.
    const busy = () => {
      if (gen !== generation || latch !== delivered) return
      latch = before
      crossing ??= crossed
      debug('a main-thread turn started before the threshold message went out; the crossing stays recorded for its end')
    }
    submit({ text: deliveryText(plugin(), step.deliver, t, tokens), line: deliveryLine(plugin(), step.deliver, t, tokens) }, false, busy)
  }

  /** Settle `r` with its resume prompt, unguarded; an unset flag submits nothing. */
  const finish = (r: Request) => {
    if (request === r) request = undefined
    if (r.resume) submit({ text: resumeText(plugin()), line: resumeLine(plugin()) }, true, resumeBusy)
  }

  /**
   * Settle `r` after its own compaction: hold the resume prompt, and submit
   * it at the window's end unless a main-thread turn started meanwhile.
   */
  const hold = (r: Request, prompt: OwnPrompt) => {
    if (request === r) request = undefined
    // A window still open is superseded: one resume prompt covers both.
    const h = { prompt }
    held = h
    try {
      edges?.delay(CONTINUATION_WINDOW_MS, () => {
        if (held !== h) return
        held = undefined
        submit(h.prompt, true, resumeBusy)
      })
    } catch (err) {
      debug(`the resume window was not started (${String(err)}); submitting the resume prompt now`)
      if (held === h) held = undefined
      submit(prompt, true, resumeBusy)
    }
  }

  /**
   * Settle `r` after its compaction did not run: one notice, the compact
   * step dropped, and with the flag a resume prompt held with the note.
   */
  const vetoed = (r: Request, reason: string) => {
    if (!r.resume) {
      // No turn follows, so a veto is told to the person here: the model is
      // not started to hear it and no window opens.
      request = undefined
      notice(`the requested compaction did not run (${reason}); no resume was requested, so no turn follows`)
      return
    }
    notice(`the requested compaction did not run (${reason}); a resume prompt follows with a note`)
    hold(r, { text: vetoedResumeText(plugin(), reason), line: vetoedResumeLine(plugin(), reason) })
  }

  /**
   * The settled compact step, run only while no main-thread turn runs (the
   * scheduled step checks that first). It awaits the `/compact` command, and
   * the hook's report of a main-conversation compaction meanwhile is the
   * outcome: landed, or vetoed with its reason. A refused command is
   * permanent and settles as a veto; so does a command that ran with no
   * outcome observed, rather than being read as a landing or retried.
   */
  const runLever = async (r: Request) => {
    try {
      await compactStep(r)
    } finally {
      // The step decided (a held resume prompt, or none): wake continuation()'s waiters if none is pending.
      settle()
    }
  }

  const compactStep = async (r: Request) => {
    if (!edges || request !== r) return
    if (!r.compact) return finish(r)
    let refused: string | undefined
    leverCompacting = true
    leverOutcome = undefined
    try {
      await edges.compact()
    } catch (err) {
      refused = `the compact command was refused: ${String(err)}`
    } finally {
      leverCompacting = false
    }
    const outcome = leverOutcome
    leverOutcome = undefined
    if (request !== r) return
    if (outcome !== undefined && outcome.skip === undefined) {
      if (r.resume) hold(r, { text: resumeText(plugin()), line: resumeLine(plugin()) })
      else request = undefined
      return
    }
    vetoed(r, outcome?.skip ?? refused ?? UNOBSERVED_REASON)
  }

  return {
    start: (bound) => {
      edges = bound
      reset()
      advisory = DEFAULT_ADVISORY
      const read = (reads += 1)
      const readAdvisory = bound.readAdvisory
      if (!readAdvisory) return
      Promise.resolve()
        .then(readAdvisory)
        .then(
          (value) => {
            if (read !== reads) return
            advisory = resolveAdvisory(value)
            // Thresholds cached under the default are figured again at the next observation.
            cached = undefined
            debug(`advisory point ${JSON.stringify(value)} read as ${describeAdvisory(advisory)}`)
          },
          (err) => {
            if (read === reads) debug(`advisory point not read (${String(err)}); the default applies`)
          },
        )
    },

    end: (reason) => {
      if (request) debug(`session.end ${reason} dropped a pending compaction request`)
      if (held) notice(`a prompt was not submitted (session.end ${reason}):\n${held.prompt.text}`)
      reset()
    },

    lever: (agentId, flag) => {
      const checked = checkLeverCall(agentId, flag)
      if ('deny' in checked) return { deny: checked.deny }
      // A repeat call while one is pending replaces the flag (latest wins, so
      // an unset one clears an earlier true) and keeps the request's
      // compact-step state.
      if (request) {
        request.resume = checked.resume
        request.ended = false
      } else request = { resume: checked.resume, compact: true, scheduled: undefined, ended: false }
      debug(`compaction requested; resume: ${checked.resume}`)
      return { result: leverResult(checked.resume) }
    },

    measure: async (context, readBreakdown) => {
      const tokens = context.tokens
      if (tokens === undefined) return
      const gen = generation
      if (!cached || cached.window !== context.window) {
        const breakdown = (await readBreakdown()).context.breakdown
        if (gen !== generation || !breakdown) return
        cached = { window: context.window, thresholds: thresholdsFor(breakdown, advisory) }
        debug(describeWindow(cached.thresholds))
      }
      const t = cached.thresholds
      if (!t) return
      // Record only: the latch baselines or re-arms here, and a crossing
      // above it is delivered by deliver().
      const level = levelAt(t, tokens)
      latch = observe(latch, level, false).latch
      if (level <= latch) crossing = undefined
      else crossing ??= { tokens }
      if (crossing && !edges?.turnRunning()) await deliver()
    },

    // Any main-thread turn start, whatever started it, is the first turn
    // after the step: it resumes the work, so the held resume would only
    // arrive after it as a stale prompt. A subagent's turn is not that turn.
    turnStarted: (agentId) => {
      if (agentId !== undefined || !held) return
      held = undefined
      debug('a turn started within the resume window; the resume prompt is not submitted')
      settle()
    },

    // The compact step runs SETTLE_MS after the turn end, and only when no
    // main-thread turn runs then, checked before every other branch: a
    // `/compact` queued behind a turn cannot be withdrawn, and that turn's
    // own auto compaction would be credited to the lever and followed by a
    // second one. A step that finds a turn running does nothing; that turn's
    // end schedules it again. An interrupted turn leaves the request pending:
    // the human is taking over. A step still queued at a later turn end never
    // ran (the engine runs no timer callback whose dispatch a hook refused),
    // so it is queued again; the token keeps the stale one inert should it run
    // after all.
    turnComplete: (agentId, reason) => {
      // A crossing recorded during the turn is delivered once the hook has
      // returned; an observation arriving after the turn end may deliver it
      // first, and the latch keeps it from being delivered twice. An aborted
      // turn's crossing waits for the next idle observation or turn end.
      if (agentId === undefined && reason !== 'aborted' && crossing && edges) {
        try {
          edges.after(() => void deliver().catch((err) => debug(`delivery failed: ${String(err)}`)))
        } catch (err) {
          debug(`the delivery was not scheduled (${String(err)}); the crossing stays recorded`)
        }
      }
      const r = request
      // The turn that carried the call has ended, whatever its reason (see leverPending).
      if (agentId === undefined && r) r.ended = true
      if (agentId !== undefined || reason === 'aborted' || !r || leverCompacting || !edges) return
      if (!r.compact) return finish(r)
      if (r.scheduled !== undefined) debug('the scheduled compaction step did not run; scheduling it again')
      const token = (dispatches += 1)
      r.scheduled = token
      try {
        edges.delay(SETTLE_MS, () => {
          if (r.scheduled !== token) return
          r.scheduled = undefined
          if (edges?.turnRunning()) {
            debug('a main-thread turn runs at the settled compaction step; it waits for that turn to end')
            return
          }
          runLever(r).catch((err) => debug(`compaction step failed: ${String(err)}`))
        })
      } catch (err) {
        if (r.scheduled === token) r.scheduled = undefined
        debug(`the compaction step was not scheduled (${String(err)}); retrying at the next turn end`)
      }
    },

    // `precompute` installs nothing, a veto leaves the conversation as it
    // was, and a subagent's or fork's own compaction is not the main
    // conversation's. A landed one resets the latch and the breakdown, and,
    // outside the lever's awaited command, drops a pending compact step.
    // Compactions run one at a time, so one seen while the command is
    // pending is the lever's own: its outcome (a landing over a veto) is kept
    // for runLever.
    compacted: (trigger, agentId, res) => {
      if (agentId !== undefined || trigger === 'precompute') return
      if (leverCompacting && (leverOutcome === undefined || leverOutcome.skip !== undefined)) leverOutcome = res
      if (res.skip !== undefined) return
      landed()
      if (leverCompacting) return
      if (request?.compact) {
        request.compact = false
        notice(
          `a ${trigger} compaction landed first, so the requested compaction is dropped; ` +
            (request.resume ? 'its resume prompt follows at the next turn end' : 'no resume was requested, so no prompt follows'),
        )
      }
    },

    continuation: () => {
      if (!continuing()) return Promise.resolve()
      return new Promise<void>((resolve) => waiters.push(resolve))
    },

    leverPending: (reason) => reason !== 'aborted' && !leverCompacting && request?.compact === true && !request.ended,
  }
}
